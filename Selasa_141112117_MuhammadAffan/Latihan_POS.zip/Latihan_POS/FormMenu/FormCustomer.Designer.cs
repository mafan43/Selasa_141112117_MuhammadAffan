﻿namespace Latihan_POS
{
    partial class FormCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCustomer));
            this.TxtAlamatCust = new System.Windows.Forms.TextBox();
            this.BtnKeluar = new System.Windows.Forms.Button();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.BtnSimpan = new System.Windows.Forms.Button();
            this.TxtEmailCust = new System.Windows.Forms.TextBox();
            this.TxHpCust = new System.Windows.Forms.TextBox();
            this.TxtNamaCust = new System.Windows.Forms.TextBox();
            this.TxtKodeCust = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // TxtAlamatCust
            // 
            this.TxtAlamatCust.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtAlamatCust.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAlamatCust.Location = new System.Drawing.Point(195, 202);
            this.TxtAlamatCust.Multiline = true;
            this.TxtAlamatCust.Name = "TxtAlamatCust";
            this.TxtAlamatCust.Size = new System.Drawing.Size(156, 23);
            this.TxtAlamatCust.TabIndex = 47;
            // 
            // BtnKeluar
            // 
            this.BtnKeluar.BackColor = System.Drawing.Color.Yellow;
            this.BtnKeluar.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeluar.Location = new System.Drawing.Point(276, 333);
            this.BtnKeluar.Name = "BtnKeluar";
            this.BtnKeluar.Size = new System.Drawing.Size(75, 26);
            this.BtnKeluar.TabIndex = 45;
            this.BtnKeluar.Text = "Keluar";
            this.BtnKeluar.UseVisualStyleBackColor = false;
            this.BtnKeluar.Click += new System.EventHandler(this.BtnKeluar_Click);
            // 
            // BtnCancel
            // 
            this.BtnCancel.BackColor = System.Drawing.Color.Yellow;
            this.BtnCancel.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCancel.Location = new System.Drawing.Point(276, 301);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(75, 26);
            this.BtnCancel.TabIndex = 44;
            this.BtnCancel.Text = "Cancel";
            this.BtnCancel.UseVisualStyleBackColor = false;
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // BtnSimpan
            // 
            this.BtnSimpan.BackColor = System.Drawing.Color.Yellow;
            this.BtnSimpan.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSimpan.Location = new System.Drawing.Point(195, 301);
            this.BtnSimpan.Name = "BtnSimpan";
            this.BtnSimpan.Size = new System.Drawing.Size(75, 26);
            this.BtnSimpan.TabIndex = 43;
            this.BtnSimpan.Text = "Simpan";
            this.BtnSimpan.UseVisualStyleBackColor = false;
            this.BtnSimpan.Click += new System.EventHandler(this.BtnSimpan_Click);
            // 
            // TxtEmailCust
            // 
            this.TxtEmailCust.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtEmailCust.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtEmailCust.Location = new System.Drawing.Point(195, 266);
            this.TxtEmailCust.Multiline = true;
            this.TxtEmailCust.Name = "TxtEmailCust";
            this.TxtEmailCust.Size = new System.Drawing.Size(156, 23);
            this.TxtEmailCust.TabIndex = 39;
            // 
            // TxHpCust
            // 
            this.TxHpCust.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxHpCust.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxHpCust.Location = new System.Drawing.Point(195, 234);
            this.TxHpCust.Multiline = true;
            this.TxHpCust.Name = "TxHpCust";
            this.TxHpCust.Size = new System.Drawing.Size(156, 23);
            this.TxHpCust.TabIndex = 38;
            // 
            // TxtNamaCust
            // 
            this.TxtNamaCust.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNamaCust.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNamaCust.Location = new System.Drawing.Point(195, 168);
            this.TxtNamaCust.Multiline = true;
            this.TxtNamaCust.Name = "TxtNamaCust";
            this.TxtNamaCust.Size = new System.Drawing.Size(156, 23);
            this.TxtNamaCust.TabIndex = 36;
            // 
            // TxtKodeCust
            // 
            this.TxtKodeCust.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtKodeCust.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtKodeCust.Location = new System.Drawing.Point(195, 135);
            this.TxtKodeCust.Multiline = true;
            this.TxtKodeCust.Name = "TxtKodeCust";
            this.TxtKodeCust.Size = new System.Drawing.Size(156, 23);
            this.TxtKodeCust.TabIndex = 32;
            // 
            // FormCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(384, 495);
            this.Controls.Add(this.TxtAlamatCust);
            this.Controls.Add(this.BtnKeluar);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnSimpan);
            this.Controls.Add(this.TxtEmailCust);
            this.Controls.Add(this.TxHpCust);
            this.Controls.Add(this.TxtNamaCust);
            this.Controls.Add(this.TxtKodeCust);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormCustomer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormCustomer";
            this.Load += new System.EventHandler(this.FormCustomer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtAlamatCust;
        private System.Windows.Forms.Button BtnKeluar;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.Button BtnSimpan;
        private System.Windows.Forms.TextBox TxtEmailCust;
        private System.Windows.Forms.TextBox TxHpCust;
        private System.Windows.Forms.TextBox TxtNamaCust;
        private System.Windows.Forms.TextBox TxtKodeCust;
    }
}