﻿namespace Latihan_POS
{
    partial class FormRegistrationBarang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRegistrationBarang));
            this.TxtNamaBrg = new System.Windows.Forms.TextBox();
            this.BtnKeluar = new System.Windows.Forms.Button();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.BtnSimpan = new System.Windows.Forms.Button();
            this.TxtHrgJual = new System.Windows.Forms.TextBox();
            this.TxtHrgBrg = new System.Windows.Forms.TextBox();
            this.TxtJlhBrg = new System.Windows.Forms.TextBox();
            this.TxtKodeBrg = new System.Windows.Forms.TextBox();
            this.TxtIdBrg = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // TxtNamaBrg
            // 
            this.TxtNamaBrg.BackColor = System.Drawing.Color.White;
            this.TxtNamaBrg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNamaBrg.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNamaBrg.Location = new System.Drawing.Point(195, 203);
            this.TxtNamaBrg.Multiline = true;
            this.TxtNamaBrg.Name = "TxtNamaBrg";
            this.TxtNamaBrg.Size = new System.Drawing.Size(156, 23);
            this.TxtNamaBrg.TabIndex = 31;
            // 
            // BtnKeluar
            // 
            this.BtnKeluar.BackColor = System.Drawing.Color.Yellow;
            this.BtnKeluar.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeluar.Location = new System.Drawing.Point(276, 366);
            this.BtnKeluar.Name = "BtnKeluar";
            this.BtnKeluar.Size = new System.Drawing.Size(75, 26);
            this.BtnKeluar.TabIndex = 29;
            this.BtnKeluar.Text = "Keluar";
            this.BtnKeluar.UseVisualStyleBackColor = false;
            this.BtnKeluar.Click += new System.EventHandler(this.BtnKeluar_Click);
            // 
            // BtnCancel
            // 
            this.BtnCancel.BackColor = System.Drawing.Color.Yellow;
            this.BtnCancel.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCancel.Location = new System.Drawing.Point(276, 334);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(75, 26);
            this.BtnCancel.TabIndex = 28;
            this.BtnCancel.Text = "Cancel";
            this.BtnCancel.UseVisualStyleBackColor = false;
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // BtnSimpan
            // 
            this.BtnSimpan.BackColor = System.Drawing.Color.Yellow;
            this.BtnSimpan.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSimpan.Location = new System.Drawing.Point(195, 334);
            this.BtnSimpan.Name = "BtnSimpan";
            this.BtnSimpan.Size = new System.Drawing.Size(75, 26);
            this.BtnSimpan.TabIndex = 27;
            this.BtnSimpan.Text = "Simpan";
            this.BtnSimpan.UseVisualStyleBackColor = false;
            this.BtnSimpan.Click += new System.EventHandler(this.BtnSimpan_Click);
            // 
            // TxtHrgJual
            // 
            this.TxtHrgJual.BackColor = System.Drawing.Color.White;
            this.TxtHrgJual.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtHrgJual.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtHrgJual.Location = new System.Drawing.Point(195, 301);
            this.TxtHrgJual.Multiline = true;
            this.TxtHrgJual.Name = "TxtHrgJual";
            this.TxtHrgJual.Size = new System.Drawing.Size(156, 23);
            this.TxtHrgJual.TabIndex = 25;
            // 
            // TxtHrgBrg
            // 
            this.TxtHrgBrg.BackColor = System.Drawing.Color.White;
            this.TxtHrgBrg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtHrgBrg.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtHrgBrg.Location = new System.Drawing.Point(195, 268);
            this.TxtHrgBrg.Multiline = true;
            this.TxtHrgBrg.Name = "TxtHrgBrg";
            this.TxtHrgBrg.Size = new System.Drawing.Size(156, 23);
            this.TxtHrgBrg.TabIndex = 23;
            // 
            // TxtJlhBrg
            // 
            this.TxtJlhBrg.BackColor = System.Drawing.Color.White;
            this.TxtJlhBrg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtJlhBrg.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtJlhBrg.Location = new System.Drawing.Point(195, 235);
            this.TxtJlhBrg.Multiline = true;
            this.TxtJlhBrg.Name = "TxtJlhBrg";
            this.TxtJlhBrg.Size = new System.Drawing.Size(156, 23);
            this.TxtJlhBrg.TabIndex = 22;
            // 
            // TxtKodeBrg
            // 
            this.TxtKodeBrg.BackColor = System.Drawing.Color.White;
            this.TxtKodeBrg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtKodeBrg.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtKodeBrg.Location = new System.Drawing.Point(195, 170);
            this.TxtKodeBrg.Multiline = true;
            this.TxtKodeBrg.Name = "TxtKodeBrg";
            this.TxtKodeBrg.Size = new System.Drawing.Size(156, 23);
            this.TxtKodeBrg.TabIndex = 20;
            // 
            // TxtIdBrg
            // 
            this.TxtIdBrg.BackColor = System.Drawing.Color.White;
            this.TxtIdBrg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtIdBrg.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtIdBrg.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.TxtIdBrg.Location = new System.Drawing.Point(195, 136);
            this.TxtIdBrg.Multiline = true;
            this.TxtIdBrg.Name = "TxtIdBrg";
            this.TxtIdBrg.Size = new System.Drawing.Size(156, 23);
            this.TxtIdBrg.TabIndex = 16;
            // 
            // FormRegistrationBarang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(134)))), ((int)(((byte)(134)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(384, 495);
            this.Controls.Add(this.TxtNamaBrg);
            this.Controls.Add(this.BtnKeluar);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnSimpan);
            this.Controls.Add(this.TxtHrgJual);
            this.Controls.Add(this.TxtHrgBrg);
            this.Controls.Add(this.TxtJlhBrg);
            this.Controls.Add(this.TxtKodeBrg);
            this.Controls.Add(this.TxtIdBrg);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormRegistrationBarang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormRegistrationBarang";
            this.Load += new System.EventHandler(this.FormRegistrationBarang_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtNamaBrg;
        private System.Windows.Forms.Button BtnKeluar;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.Button BtnSimpan;
        private System.Windows.Forms.TextBox TxtHrgJual;
        private System.Windows.Forms.TextBox TxtHrgBrg;
        private System.Windows.Forms.TextBox TxtJlhBrg;
        private System.Windows.Forms.TextBox TxtKodeBrg;
        private System.Windows.Forms.TextBox TxtIdBrg;
    }
}