﻿namespace Latihan_POS.FormMenu
{
    partial class FormRegisSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRegisSupplier));
            this.TxtAlamatSup = new System.Windows.Forms.TextBox();
            this.BtnKeluar = new System.Windows.Forms.Button();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.BtnSimpan = new System.Windows.Forms.Button();
            this.TxtEmailSup = new System.Windows.Forms.TextBox();
            this.TxHpSup = new System.Windows.Forms.TextBox();
            this.TxtNamaSup = new System.Windows.Forms.TextBox();
            this.TxtKodeSup = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // TxtAlamatSup
            // 
            this.TxtAlamatSup.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtAlamatSup.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAlamatSup.Location = new System.Drawing.Point(193, 200);
            this.TxtAlamatSup.Multiline = true;
            this.TxtAlamatSup.Name = "TxtAlamatSup";
            this.TxtAlamatSup.Size = new System.Drawing.Size(155, 23);
            this.TxtAlamatSup.TabIndex = 61;
            // 
            // BtnKeluar
            // 
            this.BtnKeluar.BackColor = System.Drawing.Color.Yellow;
            this.BtnKeluar.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeluar.Location = new System.Drawing.Point(275, 333);
            this.BtnKeluar.Name = "BtnKeluar";
            this.BtnKeluar.Size = new System.Drawing.Size(75, 25);
            this.BtnKeluar.TabIndex = 59;
            this.BtnKeluar.Text = "Keluar";
            this.BtnKeluar.UseVisualStyleBackColor = false;
            this.BtnKeluar.Click += new System.EventHandler(this.BtnKeluar_Click);
            // 
            // BtnCancel
            // 
            this.BtnCancel.BackColor = System.Drawing.Color.Yellow;
            this.BtnCancel.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCancel.Location = new System.Drawing.Point(274, 301);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(75, 25);
            this.BtnCancel.TabIndex = 58;
            this.BtnCancel.Text = "Cancel";
            this.BtnCancel.UseVisualStyleBackColor = false;
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // BtnSimpan
            // 
            this.BtnSimpan.BackColor = System.Drawing.Color.Yellow;
            this.BtnSimpan.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSimpan.Location = new System.Drawing.Point(195, 301);
            this.BtnSimpan.Name = "BtnSimpan";
            this.BtnSimpan.Size = new System.Drawing.Size(75, 25);
            this.BtnSimpan.TabIndex = 57;
            this.BtnSimpan.Text = "Simpan";
            this.BtnSimpan.UseVisualStyleBackColor = false;
            this.BtnSimpan.Click += new System.EventHandler(this.BtnSimpan_Click);
            // 
            // TxtEmailSup
            // 
            this.TxtEmailSup.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtEmailSup.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtEmailSup.Location = new System.Drawing.Point(193, 265);
            this.TxtEmailSup.Multiline = true;
            this.TxtEmailSup.Name = "TxtEmailSup";
            this.TxtEmailSup.Size = new System.Drawing.Size(155, 23);
            this.TxtEmailSup.TabIndex = 55;
            // 
            // TxHpSup
            // 
            this.TxHpSup.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxHpSup.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxHpSup.Location = new System.Drawing.Point(193, 234);
            this.TxHpSup.Multiline = true;
            this.TxHpSup.Name = "TxHpSup";
            this.TxHpSup.Size = new System.Drawing.Size(155, 23);
            this.TxHpSup.TabIndex = 54;
            // 
            // TxtNamaSup
            // 
            this.TxtNamaSup.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNamaSup.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNamaSup.Location = new System.Drawing.Point(193, 167);
            this.TxtNamaSup.Multiline = true;
            this.TxtNamaSup.Name = "TxtNamaSup";
            this.TxtNamaSup.Size = new System.Drawing.Size(155, 23);
            this.TxtNamaSup.TabIndex = 52;
            // 
            // TxtKodeSup
            // 
            this.TxtKodeSup.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtKodeSup.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtKodeSup.Location = new System.Drawing.Point(193, 135);
            this.TxtKodeSup.Multiline = true;
            this.TxtKodeSup.Name = "TxtKodeSup";
            this.TxtKodeSup.Size = new System.Drawing.Size(155, 23);
            this.TxtKodeSup.TabIndex = 48;
            // 
            // FormRegisSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(384, 495);
            this.Controls.Add(this.TxtAlamatSup);
            this.Controls.Add(this.BtnKeluar);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnSimpan);
            this.Controls.Add(this.TxtEmailSup);
            this.Controls.Add(this.TxHpSup);
            this.Controls.Add(this.TxtNamaSup);
            this.Controls.Add(this.TxtKodeSup);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormRegisSupplier";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtAlamatSup;
        private System.Windows.Forms.Button BtnKeluar;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.Button BtnSimpan;
        private System.Windows.Forms.TextBox TxtEmailSup;
        private System.Windows.Forms.TextBox TxHpSup;
        private System.Windows.Forms.TextBox TxtNamaSup;
        private System.Windows.Forms.TextBox TxtKodeSup;
    }
}