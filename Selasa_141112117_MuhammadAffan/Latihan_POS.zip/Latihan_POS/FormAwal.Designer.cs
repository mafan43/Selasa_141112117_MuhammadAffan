﻿namespace Latihan_POS
{
    partial class FormAwal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAwal));
            this.barangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.custToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PicBox2 = new System.Windows.Forms.PictureBox();
            this.PicBox = new System.Windows.Forms.PictureBox();
            this.PicBox4 = new System.Windows.Forms.PictureBox();
            this.PicBox1 = new System.Windows.Forms.PictureBox();
            this.PicBoxCust = new System.Windows.Forms.PictureBox();
            this.PicBoxClose = new System.Windows.Forms.PictureBox();
            this.PicBoxSup = new System.Windows.Forms.PictureBox();
            this.PicEditCust = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxCust)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxSup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicEditCust)).BeginInit();
            this.SuspendLayout();
            // 
            // barangToolStripMenuItem
            // 
            this.barangToolStripMenuItem.Name = "barangToolStripMenuItem";
            this.barangToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.barangToolStripMenuItem.Text = "Barang";
            // 
            // registrationToolStripMenuItem
            // 
            this.registrationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.barangToolStripMenuItem,
            this.custToolStripMenuItem});
            this.registrationToolStripMenuItem.Name = "registrationToolStripMenuItem";
            this.registrationToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.registrationToolStripMenuItem.Text = "Registration";
            // 
            // custToolStripMenuItem
            // 
            this.custToolStripMenuItem.Name = "custToolStripMenuItem";
            this.custToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.custToolStripMenuItem.Text = "Customer";
            // 
            // PicBox2
            // 
            this.PicBox2.Image = ((System.Drawing.Image)(resources.GetObject("PicBox2.Image")));
            this.PicBox2.Location = new System.Drawing.Point(282, 70);
            this.PicBox2.Name = "PicBox2";
            this.PicBox2.Size = new System.Drawing.Size(129, 130);
            this.PicBox2.TabIndex = 10;
            this.PicBox2.TabStop = false;
            this.PicBox2.MouseLeave += new System.EventHandler(this.PicBox2_MouseLeave);
            this.PicBox2.MouseHover += new System.EventHandler(this.pictureBox2_MouseHover);
            // 
            // PicBox
            // 
            this.PicBox.Image = ((System.Drawing.Image)(resources.GetObject("PicBox.Image")));
            this.PicBox.Location = new System.Drawing.Point(147, 70);
            this.PicBox.Name = "PicBox";
            this.PicBox.Size = new System.Drawing.Size(129, 130);
            this.PicBox.TabIndex = 9;
            this.PicBox.TabStop = false;
            this.PicBox.Click += new System.EventHandler(this.PicBox_Click);
            this.PicBox.MouseLeave += new System.EventHandler(this.PicBox_MouseLeave);
            this.PicBox.MouseHover += new System.EventHandler(this.PicBox_MouseHover);
            // 
            // PicBox4
            // 
            this.PicBox4.BackColor = System.Drawing.Color.Transparent;
            this.PicBox4.Image = ((System.Drawing.Image)(resources.GetObject("PicBox4.Image")));
            this.PicBox4.Location = new System.Drawing.Point(12, 9);
            this.PicBox4.Name = "PicBox4";
            this.PicBox4.Size = new System.Drawing.Size(248, 55);
            this.PicBox4.TabIndex = 6;
            this.PicBox4.TabStop = false;
            this.PicBox4.Click += new System.EventHandler(this.PicBox4_Click);
            // 
            // PicBox1
            // 
            this.PicBox1.Image = ((System.Drawing.Image)(resources.GetObject("PicBox1.Image")));
            this.PicBox1.Location = new System.Drawing.Point(12, 70);
            this.PicBox1.Name = "PicBox1";
            this.PicBox1.Size = new System.Drawing.Size(129, 130);
            this.PicBox1.TabIndex = 4;
            this.PicBox1.TabStop = false;
            this.PicBox1.Click += new System.EventHandler(this.PicBox1_Click);
            this.PicBox1.MouseLeave += new System.EventHandler(this.PicBox1_MouseLeave);
            this.PicBox1.MouseHover += new System.EventHandler(this.PicBox1_MouseHover);
            // 
            // PicBoxCust
            // 
            this.PicBoxCust.Image = ((System.Drawing.Image)(resources.GetObject("PicBoxCust.Image")));
            this.PicBoxCust.Location = new System.Drawing.Point(535, 12);
            this.PicBoxCust.Name = "PicBoxCust";
            this.PicBoxCust.Size = new System.Drawing.Size(25, 30);
            this.PicBoxCust.TabIndex = 11;
            this.PicBoxCust.TabStop = false;
            this.PicBoxCust.Click += new System.EventHandler(this.PicBoxCust_Click);
            this.PicBoxCust.MouseLeave += new System.EventHandler(this.PicBoxCust_MouseLeave);
            this.PicBoxCust.MouseHover += new System.EventHandler(this.PicBoxCust_MouseHover);
            // 
            // PicBoxClose
            // 
            this.PicBoxClose.Image = ((System.Drawing.Image)(resources.GetObject("PicBoxClose.Image")));
            this.PicBoxClose.Location = new System.Drawing.Point(707, 2);
            this.PicBoxClose.Name = "PicBoxClose";
            this.PicBoxClose.Size = new System.Drawing.Size(27, 30);
            this.PicBoxClose.TabIndex = 12;
            this.PicBoxClose.TabStop = false;
            this.PicBoxClose.Click += new System.EventHandler(this.PicBoxClose_Click);
            this.PicBoxClose.MouseLeave += new System.EventHandler(this.PicBoxClose_MouseLeave);
            this.PicBoxClose.MouseHover += new System.EventHandler(this.PicBoxClose_MouseHover);
            // 
            // PicBoxSup
            // 
            this.PicBoxSup.Image = ((System.Drawing.Image)(resources.GetObject("PicBoxSup.Image")));
            this.PicBoxSup.Location = new System.Drawing.Point(537, 48);
            this.PicBoxSup.Name = "PicBoxSup";
            this.PicBoxSup.Size = new System.Drawing.Size(25, 27);
            this.PicBoxSup.TabIndex = 13;
            this.PicBoxSup.TabStop = false;
            this.PicBoxSup.Click += new System.EventHandler(this.PicBoxSup_Click);
            this.PicBoxSup.MouseLeave += new System.EventHandler(this.PicBoxSup_MouseLeave);
            this.PicBoxSup.MouseHover += new System.EventHandler(this.PicBoxSup_MouseHover);
            // 
            // PicEditCust
            // 
            this.PicEditCust.Image = ((System.Drawing.Image)(resources.GetObject("PicEditCust.Image")));
            this.PicEditCust.Location = new System.Drawing.Point(566, 12);
            this.PicEditCust.Name = "PicEditCust";
            this.PicEditCust.Size = new System.Drawing.Size(27, 29);
            this.PicEditCust.TabIndex = 14;
            this.PicEditCust.TabStop = false;
            this.PicEditCust.Click += new System.EventHandler(this.PicEditCust_Click);
            this.PicEditCust.MouseLeave += new System.EventHandler(this.PicEditCust_MouseLeave);
            this.PicEditCust.MouseHover += new System.EventHandler(this.pictureBox1_MouseHover);
            // 
            // FormAwal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 499);
            this.Controls.Add(this.PicEditCust);
            this.Controls.Add(this.PicBoxSup);
            this.Controls.Add(this.PicBoxClose);
            this.Controls.Add(this.PicBoxCust);
            this.Controls.Add(this.PicBox2);
            this.Controls.Add(this.PicBox);
            this.Controls.Add(this.PicBox4);
            this.Controls.Add(this.PicBox1);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormAwal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormAwal";
            this.Load += new System.EventHandler(this.FormAwal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PicBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxCust)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxSup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicEditCust)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem barangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem custToolStripMenuItem;
        private System.Windows.Forms.PictureBox PicBox1;
        private System.Windows.Forms.PictureBox PicBox4;
        private System.Windows.Forms.PictureBox PicBox;
        private System.Windows.Forms.PictureBox PicBox2;
        private System.Windows.Forms.PictureBox PicBoxCust;
        private System.Windows.Forms.PictureBox PicBoxClose;
        private System.Windows.Forms.PictureBox PicBoxSup;
        private System.Windows.Forms.PictureBox PicEditCust;
    }
}

